// Test.cpp

#include "tools/test/Common.h"
#include "tools/test/InputHandler.h"
#include "tools/test/PlaySession.h"

#include <framework/string/Slice.h>
#include <framework/system/BytesOrder.h>
#include <framework/configure/Config.h>
using namespace framework::string;
using namespace framework::configure;
using namespace framework::logger;
using namespace framework::network;

#include <boost/thread/thread.hpp>
using namespace boost::system;

#include <iostream>
#include <fstream>

#ifdef BOOST_WINDOWS_API
#  ifdef UNDER_CE
#    define localtime_r(x, y) *y = *localtime(x)
#  else 
#    define localtime_r(x, y) localtime_s(y, x)
#  endif
#endif

void play_movie(
                Config & conf, 
                InputHandler & std_in, 
                std::string const & name)
{
    PlaySession session(conf);
    PP_int32 ec = session.open(std_in, name.c_str());
    while (!ec) {
        ec = session.play_go_on();
        std::string cmd;
        if (std_in.get_one(cmd)) {
            std::vector<std::string> cmd_args;
            slice<std::string>(cmd, std::inserter(cmd_args, cmd_args.end()), " ");
            if (cmd_args[0] == "seek") {
                if (cmd_args.size() >= 2) {
                    PP_uint32 time = framework::string::parse<PP_uint32>(cmd_args[1]);
                    session.seek(time);
                }
            } else if (cmd_args[0] == "pause") {
                session.pause();
            } else if (cmd_args[0] == "resume") {
                session.resume();
            } else if (cmd_args[0] == "close") {
                break;
            } else if (cmd_args[0] == "ui") {
                std::string msg = "abc";
                session.submit_ui_log(msg.c_str(), msg.length());
                break;
            } else {
                std::cout << "play_movie: " << "unkonwn command " << cmd_args[0] << std::endl;
            }
        }
    }
    session.close();
    std::cout << "exit play movie" << std::endl;
}

void msg_out(PP_uint32 numbers)
{
    DialogMessage * vector = NULL;
    vector = new DialogMessage[numbers];
    //numbers = PPBOX_DialogMessage(vector, numbers, module.c_str(), 5);
    numbers = PPBOX_DialogMessage(vector, numbers, NULL, 5);
    if (numbers > 0) {
        for (size_t i = 0; i < numbers; ++i) {

            time_t tt = vector[i].time;
            struct tm lt;
            char buf[40];
            localtime_r(&tt, &lt);
            strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &lt);

            std::cout << "msg:" << i << ", [" << buf << "] ["
                << vector[i].module << "] " << vector[i].msg << std::endl;
        }
    }
    delete [] vector;
    vector = NULL;
}

int main(int argc, char * argv[])
{
    Config conf("ppbox_test.conf");
    global_logger().load_config(conf);

    std::string gid;
    std::string pid;
    std::string auth;

    conf.register_module("Certify")
        << CONFIG_PARAM_RDWR(gid)
        << CONFIG_PARAM_RDWR(pid)
        << CONFIG_PARAM_RDWR(auth);

    bool is_debug = false;

    std::string play_list;
    if (argc >= 2) {
        if (argv[1][0] == '-') {
            if (argv[1][1] == 'c') {
                NetName addr("127.0.0.1:1111");
                if (argc >= 3) {
                    addr.from_string(argv[2]);
                }
                InputHandler std_out(addr, false);
                std::string cmd;
                PP_uint32 numbers = 1;
                while (std::getline(std::cin, cmd)) {
                    std::vector<std::string> cmd_args;
                    slice<std::string>(cmd, std::inserter(cmd_args, cmd_args.end()), " ");
                    if (is_debug) {
                        if (cmd_args.empty()) {
                            msg_out(numbers);
                            continue;
                        } else if (cmd_args[0] == "xxx") {
                            is_debug = false;
                            PPBOX_DebugMode(false);
                            continue;
                        } else if (isdigit(cmd_args[0][0])) {
                            numbers = framework::string::parse<PP_uint32>(cmd_args[0]);
                            if (numbers <= 0) {
                                numbers = 1;
                            }

                            msg_out(numbers);
                            continue;
                        }
                    }

                    if (cmd_args.empty()) {
                    } else if (cmd_args[0] == "debug") {
                        is_debug = true;
                        PPBOX_DebugMode(true);
                        {
                            //std_out.put_one("open 1d7c1WCcaMih2c7j4a5amciYzMuUx2JamMmYzqCUymtamciY0aGUyWJam5SYzZ6Ux5ZamZmYz6DOx6GtZdHjnw%3d%3d");
                        }
                    } else if (cmd_args[0] == "start") {
                        PP_int32 ec = PPBOX_StartP2PEngine(gid.c_str(), pid.c_str(), auth.c_str());
                        if (ppbox_success != ec) {
                            std::cout << "start p2p engine: (" << ec << ")" << PPBOX_GetLastErrorMsg() << std::endl;
                            break;
                        }
                    } else if (cmd_args[0] == "config") {
                    } else {
                        std_out.put_one(cmd);
                    }
                }
                return 0;
            } else if (argv[1][1] == 'l') {
                if (argc >= 3) {
                    play_list = argv[2];
                }
            }
        } else {
            conf.profile().pre_set(std::string("Console.name=") + argv[1]);
        }
    }

    std::string name = 
        "ppvod://1d7c1WCcaMih2c7j4a5amZuYz8yUx2hamZubkMukipaWZ5WYzcyUxpheZdHjnw%3d%3d";
    NetName addr("0.0.0.0:1111");

    conf.register_module("Console")
        << CONFIG_PARAM_RDWR(name)
        << CONFIG_PARAM_RDWR(addr);

    InputHandler std_in(addr);

    PP_int32 ec = PPBOX_StartP2PEngine(gid.c_str(), pid.c_str(), auth.c_str());
    if (ppbox_success != ec) {
        std::cout << "start p2p engine: (" << ec << ")" << PPBOX_GetLastErrorMsg() << std::endl;
        return 0;
    }

    if (!play_list.empty()) {
        std::ifstream ifs(play_list.c_str());
        while (std::getline(ifs, name) && !name.empty()) {
            if (name[0] == '#')
                continue;
            if (name.at(name.size() - 1) == '\r') {
                name.erase(name.size() - 1);
            }

            boost::thread th(
                boost::bind(play_movie, boost::ref(conf), boost::ref(std_in), name));
            th.join();
        }
    }

    if (!name.empty()) {
        boost::thread th(
            boost::bind(play_movie, boost::ref(conf), boost::ref(std_in), name));
        th.join();
    }

    bool exit = false;
    while (1) {
        std::string cmd;
        if (std_in.get_one(cmd)) {
            std::vector<std::string> cmd_args;
            slice<std::string>(cmd, std::inserter(cmd_args, cmd_args.end()), " ");
            if (cmd_args[0] == "open") {
                if (cmd_args.size() >= 2) {
                    name = cmd_args[1];
                }

                boost::thread th(
                    boost::bind(play_movie, boost::ref(conf), boost::ref(std_in), name));
                th.join();
                //play_movie(conf, std_in, name);
            } else if (cmd_args[0] == "stop") {
                break;
            } else if (cmd_args[0] == "exit") {
                exit = true;
                break;
            } else if (cmd_args[0] == "restart") {
                std::cout << "restart" << std::endl;
                PPBOX_StopP2PEngine();
                ec = PPBOX_StartP2PEngine(gid.c_str(), pid.c_str(), auth.c_str());
                if (ppbox_success != ec) {
                    std::cout << "start p2p engine: (" << ec << ")" << PPBOX_GetLastErrorMsg() << std::endl;
                    break;
                }
            } else if (cmd_args[0] == "ui") {
                static std::string msg = "abc";
                std::cout << cmd_args[0] << msg << std::endl;
                PPBOX_SubmitMessage(msg.c_str(), msg.length());
            } else {
                std::cout << "main: " << "unkonwn command " << cmd_args[0] << std::endl;
            }
        } else {
            boost::this_thread::sleep(boost::posix_time::milliseconds(500));
        }
    }

    if (exit) {
        std::cout << "exit" << std::endl;
    } else {
        std::cout << "stop" << std::endl;
        PPBOX_StopP2PEngine();
    }

    //std::cout << "press any key to continue..." << std::flush;
    //std::cin.get();

    return 0;
}
